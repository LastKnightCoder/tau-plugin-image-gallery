# 存储与网络

## 私有存储

`context.storage` 是插件自己的键值存储，适合保存设置、进度、缓存等小块数据。

```ts
const saved = await context.storage.get("count");
const count = typeof saved === "number" ? saved : 0;
await context.storage.set("count", count + 1);
```

| 方法              | 说明                           |
| ----------------- | ------------------------------ |
| `get(key)`        | 读取，不存在时返回 `undefined` |
| `set(key, value)` | 保存或覆盖                     |
| `delete(key)`     | 删除                           |

### 数据保存在哪里

- 按插件和工作区隔离：同一个插件在不同工作区读到的是各自的数据，也读不到其他插件的数据。
- 保存在工作区的笔记库里，随云同步。用户换一台设备，也能读到同样的数据。
- 停用、重启、更新插件都不会删除数据。用户卸载插件时可以选择是否一并删除。
- 数据跟随插件 ID。改了 ID，就成了另一个插件，读不到原来的数据。

### 能存什么

值必须是 JSON：`null`、布尔值、字符串、有限数字，以及由它们组成的数组和普通对象。不能存 `undefined`、函数、`Date`、`Map`、`NaN`、`Infinity` 或循环引用；日期先转成字符串或时间戳。

单个值不超过 1 MB。更大的内容（比如一篇长文）放进[插件内容](user-data.md#插件内容)的正文里。

### 使用要点

- **读取后校验**。`get` 返回的是 `JsonValue`，不带类型保证。数据可能来自旧版本的插件，也可能在其他设备上被修改过，使用前先检查结构，不符合时用默认值或提示错误。
- **改了要保存**。修改 `get` 返回的对象不会自动写回，必须再调用 `set`。
- **读写不是原子的**。"先 `get` 再 `set`"之间如果有另一次写入，后写的会覆盖先写的。保存期间禁用重复提交，模板的计数器按钮就是这样做的。
- **兼顾新旧版本**。用户可以把插件恢复到上一版，但数据不会跟着回退。改变数据结构时，让新版本能读懂旧数据，也尽量让旧版本读到新数据时不出错（例如只新增字段，不改已有字段的含义）。
- **不要存凭据**。账号、Token 这类配置会随笔记库同步，不应放在这里。服务提供方的账号配置使用专门的配置保存接口，见[服务提供方](providers/README.md)。

## 网络请求

用 `context.fetch` 发起网络请求。它的参数和返回值与标准的 `fetch` 相同：

```ts
const response = await context.fetch("https://api.example.com/status", {
  headers: { Authorization: `Bearer ${token}` },
});
if (!response.ok) throw new Error(`请求失败：${response.status}`);
const data: unknown = await response.json();
```

与直接调用浏览器的 `fetch` 相比：

- 请求由 Tau 代为发出，不受浏览器跨域（CORS）限制，也不会携带浏览器的 Cookie。需要认证时，自己在请求头里提供。
- 插件停用时，进行中的请求会被自动取消。你也可以照常传入自己的 `signal`，两者任一中止都会取消请求。

注意：

- 和标准 `fetch` 一样，HTTP 4xx、5xx 不会抛出异常，要检查 `response.ok`。
- 响应数据先校验再使用，尤其是写入存储之前。
- 不要把私人的 API Key 写进源码。需要用户自己的凭据时，让用户在设置中填写。
- 能读到的用户数据都可以通过网络发送出去。只在功能确实需要时这样做，并在 README 里向用户说明。
