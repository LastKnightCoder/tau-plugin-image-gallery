import React from "react";
interface ResizeableAndHideableSidebarProps {
    width: number;
    open: boolean;
    onWidthChange?: (width: number, actualWidth?: number) => void;
    onActualWidthChange?: (actualWidth: number) => void;
    onToggle?: () => void;
    className?: string;
    style?: React.CSSProperties;
    children: React.ReactNode;
    minWidth?: number;
    maxWidth?: number;
    /**
     * 拖拽条所在的边。
     * 语义是“resize handle 在组件哪一侧”，不是“侧边栏停靠在哪一侧”。
     * 例如：
     * - 左侧侧边栏通常传 `right`
     * - 右侧侧边栏通常传 `left`
     */
    resizeHandleSide?: "left" | "right";
    /**
     * @deprecated 兼容旧调用，等价于 `resizeHandleSide`
     */
    side?: "left" | "right";
    /** 侧边栏的位置（左侧或右侧），用于确定按钮显示位置 */
    sidebarPosition?: "left" | "right";
    disableResize?: boolean;
    handleOffset?: number;
    /**
     * 收起后是否在边缘显示统一的 hover 展开按钮。
     * 适合“收起时完全不可见，只在边缘悬浮展开”的场景。
     */
    showInternalExpandButtonWhenClosed?: boolean;
    /** 透传 WidthResizable：常驻淡分隔线标出拖拽边界 */
    showDivider?: boolean;
    /** 以 flex 铺满父级剩余空间，替代固定宽度（如视频笔记收起对话后材料栏独占） */
    fillRemaining?: boolean;
}
declare const ResizeableAndHideableSidebar: (props: ResizeableAndHideableSidebarProps) => import("react/jsx-runtime").JSX.Element;
export default ResizeableAndHideableSidebar;
