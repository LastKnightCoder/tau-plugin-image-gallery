import { type ReactNode, type Ref } from "react";
interface FadeScrollProps {
    className?: string;
    children?: ReactNode;
    /** 需要拿到滚动容器时用（虚拟列表的 getScrollElement、滚动监听）；对象 ref 或回调 ref */
    scrollRef?: Ref<HTMLDivElement | null>;
    /** 内部有 motion 布局动画时开启：渲染为 motion.div 并声明 layoutScroll，动画按滚动偏移校正 */
    layoutScroll?: boolean;
    /** 关掉顶部渐隐（默认开）：滚动区顶部紧邻实底工具栏时，渐隐带落在实底上只会显脏 */
    topFade?: boolean;
}
/**
 * 面板内的纵向滚动区：接 edge fade（对齐壳层 useEdgeFade 协议），只在可滚方向渐隐，
 * 内容不贴着面板边缘被硬切；滚动条内缩不贴右缘。右侧 6px 透明边算在宽度里，
 * 调用方右内边距相应减 6px；类名经 cn 合并，调用方可覆盖透明边宽度（如 border-r-[3px]）。
 */
export declare function FadeScroll({ className, children, scrollRef, layoutScroll, topFade, }: FadeScrollProps): import("react/jsx-runtime").JSX.Element;
export {};
