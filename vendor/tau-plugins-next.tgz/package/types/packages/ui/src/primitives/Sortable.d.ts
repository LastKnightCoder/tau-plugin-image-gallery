import { type KeyboardEvent, type PointerEvent, type ReactNode } from "react";
export interface SortableHandleProps {
    onPointerDown(event: PointerEvent<HTMLElement>): void;
    onKeyDown(event: KeyboardEvent<HTMLElement>): void;
    tabIndex: number;
    "aria-roledescription": string;
}
export interface SortableItemState {
    index: number;
    /** 正在被拖动的那一项 */
    dragging: boolean;
    /** 拖动经过、松手后会放到这里 */
    over: boolean;
    /** 展开到拖动手柄上；也可以展开到整项上，整项都能拖 */
    handleProps: SortableHandleProps;
}
export interface SortableProps<T> {
    items: readonly T[];
    getKey(item: T): string;
    /** 把 from 位置的项移到 to 位置 */
    onMove(from: number, to: number): void;
    renderItem(item: T, state: SortableItemState): ReactNode;
    className?: string;
    /** 每一项外层容器的类名 */
    itemClassName?: string;
    disabled?: boolean;
}
/**
 * 列表与网格排序：按住手柄拖到另一项上松手即移到那里；手柄获得焦点时方向键前后移动一位，Esc 取消拖动。
 * 用指针事件实现，不依赖拖放 API，任何容器（含编辑器里的块）都能用。
 */
export declare function Sortable<T>({ items, getKey, onMove, renderItem, className, itemClassName, disabled, }: SortableProps<T>): import("react/jsx-runtime").JSX.Element;
