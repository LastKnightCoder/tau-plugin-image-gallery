import { ReactNode } from "react";
interface PortalToBodyProps {
    children: ReactNode;
    container?: HTMLElement;
}
declare const PortalToBody: ({ children, container }: PortalToBodyProps) => import("react").ReactPortal;
export default PortalToBody;
