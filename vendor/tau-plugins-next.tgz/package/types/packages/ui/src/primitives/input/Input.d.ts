/**
 * Input —— 文本输入基础件（方案 A「经典描边」，mockups/input/，2026-09-19 定稿）。
 *
 * 形制：surface 亮底 + line-1 描边 + radius-sm——「浮起物」语感（2026-09-17 表单
 * 控件口径），与 Select / DatePicker 触发器同族同皮；focus = accent 描边 + 3px ring。
 * 原生 input 零样式透传（IME / autofill / 无障碍白送），形制挂容器上。
 *
 * 状态语义：
 *  - 错误态正源是原生 aria-invalid（无 status prop）：容器经 has- 变体换 danger
 *    描边 / danger-soft ring——视觉与读屏语义锁死在同一属性上；判定（zod）与
 *    错误文案（Field 体系框外）、touched 策略都归表单层
 *  - 只读：框在、精气神收掉——readOnly 透传后文字转 ink-2、光标 default、
 *    hover/focus 零响应（仍可选中复制）；禁用 = 原生 disabled + 整体降透明
 *
 * 槽位：lead 前缀 icon（16px lucide，focus 转 accent-text）+ clearable 清空 ×
 * （容器 hover/focus 且有值时显现——visibility:hidden 不响应自身 hover，挂容器；
 * tabIndex=-1 不抢 Tab 流，清空后焦点留在输入框）。
 * 文本后缀 / addon 组合等装备位归后续裁决（mockups 方案 D），不预置。
 */
import { type ComponentProps } from "react";
import type { LucideIcon } from "lucide-react";
export interface InputProps extends Omit<ComponentProps<"input">, "size"> {
    /** 前缀 icon（16px lucide；focus 时转 accent-text） */
    lead?: LucideIcon;
    /** 有值时容器 hover/focus 显现清空 ×；点击清空并保留焦点 */
    clearable?: boolean;
    size?: "sm" | "md";
    /** 形态：outlined（默认，亮底描边浮起物）| bare（无皮行内形态——无边框背景与
     *  focus 反馈，高度与选中表现归宿主，如行内编辑单元格） */
    variant?: "outlined" | "bare";
    /** 外框容器的类名（默认 w-full 撑满）：定宽 / flex 伸缩等布局写这里；
     *  className 落到内部 <input>（文字对齐、字号等） */
    wrapperClassName?: string;
}
export declare function Input({ lead: Lead, clearable, size, variant, className, wrapperClassName, onChange, defaultValue, ref, ...props }: InputProps): import("react/jsx-runtime").JSX.Element;
