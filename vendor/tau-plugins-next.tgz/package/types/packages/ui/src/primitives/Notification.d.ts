/**
 * Notification 基础件 —— 右上角通知卡栈（mockups/notification/，承载方案 A + 卡片 V4）。
 *
 * 与 Toast 分工：Toast 是「你刚做了什么」的一句话回执；Notification 承载不是当下操作
 * 引发的事件（协作者、应用更新、后台任务），有来源 / 标题 / 说明，常需作答。
 *
 * 卡片：34px 身份位（人 = 派生色头像，系统 = 中性图标，成败 = soft 底语义墨）+ 文字列
 * （标题与「来源 · 相对时间」同行，说明至多 2 行）+ 横跨整卡的等宽按钮条（主按钮放最右，
 * 次要统一描边——等分格里每格都要看得出是按钮）。不描边，ring + lift + float 三层影；
 * 关闭钮悬停/聚焦时出现在左上外沿，不与时间抢右上角。
 * 卡栈：新的在上，只完整显示最新 3 张，更多按底边缩放露 8px 纸边叠 2 层；关掉一张
 * 后面的依次补位，计数标签只报数不可点，另有「全部清除」。
 * 停留：sticky（需作答）常驻；否则 8s 自动关，悬停与作答中冻结。
 * 作答：onClick 返回 promise 时该按钮 loading、整条锁定；兑现 → 有 resolvedText 收成
 * 结果行 1.6s 后退场，否则直接退场；拒绝 → 说明位换成错误文案、按钮解锁。
 * 不抢焦点（role=status + aria-live polite），不接 Esc（非阻断浮层，同 Toast）。
 * 层级 z-[190]：Toast（200）压在通知之上，回执不被卡栈挡住。
 *
 * 用法：壳层挂载 <NotificationHost /> 一次；任意处 notify({...}) 返回 id，
 * notify.update(id, patch) / notify.dismiss(id?) / notify.isActive(id)。同 id 再次
 * notify = 原位更新（去重）。
 * 锚定角默认右上，可传 placement="bottom-right" 纯镜像到右下；系统通知独立窗口另可
 * 传 autoDismiss={false} 关掉自动关闭、className 覆盖容器贴边定位，并用 onItemsChange
 * （id 列表增减）与 onCardClick（卡主体点击）把卡栈生命周期桥接到宿主窗口。
 */
import { type ComponentProps } from "react";
import { type LucideIcon } from "lucide-react";
export type NotificationTone = "neutral" | "ok" | "danger";
export interface NotificationAction {
    label: string;
    /** 主动作（accent 实心）；至多一个，放在数组末尾（主按钮在最右） */
    primary?: boolean;
    /** 返回 promise 即进入作答中：按钮 loading、整条锁定，兑现后退场，拒绝则卡内报错 */
    onClick?: () => unknown;
    /** 作答成功后的结果行文案（如「已同意林然加入协作」）；不给则直接退场 */
    resolvedText?: string;
}
export interface NotificationOptions {
    /** 业务键：同 id 再次 notify 原位更新而非新增（如 "app-update"） */
    id?: string;
    title: string;
    body?: string;
    /** 来源（「协作」「应用更新」），与相对时间同排在标题右侧 */
    source?: string;
    /** 身份位图标；缺省按 tone 取（neutral 铃铛 / ok 对勾 / danger 警示） */
    icon?: LucideIcon;
    /** 人发起的通知：头像文字（通常取名字首字），优先于 icon */
    avatar?: string;
    /** 头像取色种子（如用户 id），同人恒同色；缺省用 avatar 本身 */
    avatarSeed?: string;
    /** 语义只染身份位；卡片本体一律中性 */
    tone?: NotificationTone;
    /** 至多 2 个 */
    actions?: NotificationAction[];
    /** 需作答：常驻到有答案为止（默认 false = 纯告知，duration 后自动关） */
    sticky?: boolean;
    duration?: number;
    /** 事件发生时间（毫秒），缺省为 notify 调用时刻 */
    timestamp?: number;
}
export interface NotificationItem extends Omit<NotificationOptions, "id" | "sticky" | "duration" | "timestamp"> {
    id: string;
    sticky: boolean;
    duration: number;
    timestamp: number;
    /** 作答中的动作下标 */
    busy?: number;
    /** 作答成功后的结果行（卡片收成一行） */
    resolvedText?: string;
    /** 作答失败文案（替换说明位） */
    error?: string;
    leaving?: boolean;
}
export declare function notify(options: NotificationOptions): string;
export declare namespace notify {
    var update: (id: string, patch: Partial<Omit<NotificationOptions, "id">>) => void;
    var dismiss: (id?: string) => void;
    var isActive: (id: string) => boolean;
}
export interface NotificationCardProps extends Omit<ComponentProps<"div">, "children"> {
    item: NotificationItem;
    /** 相对时间的参照时刻（Host 每 30s 刷新；样板间标本可固定） */
    now?: number;
    onAction?: (index: number) => void;
    onClose?: () => void;
    /** 关闭钮常显（样板间悬停态标本用；产品里靠 hover / focus-within 出现） */
    showClose?: boolean;
}
/**
 * 单张通知卡（受 item 驱动的纯展示件）。导出供样板间构造常显标本——产品代码只应
 * 消费 notify 命令式 API 与 NotificationHost。
 */
export declare function NotificationCard({ item, now, onAction, onClose, showClose, className, ...props }: NotificationCardProps): import("react/jsx-runtime").JSX.Element;
export interface NotificationHostProps {
    /** 卡栈锚定角，默认 "top-right" */
    placement?: "top-right" | "bottom-right";
    /** false 时所有卡都不自动关闭（系统通知窗口用），默认 true */
    autoDismiss?: boolean;
    /** 覆盖容器定位类（例如独立窗口里贴边 top-0/bottom-0 right-0），经 cn() 合并 */
    className?: string;
    /**
     * store 内 id 列表变化时回报（按「已从 store 移除」口径：退场动画中的卡仍在列表里，
     * 直到 LEAVE_MS 后真正移除才消失）；挂载时回报一次当前列表。经 id 串比较去抖，
     * 原位更新等内容变化不会触发。
     */
    onItemsChange?: (ids: string[]) => void;
    /** 非叠层卡主体被点击（卡内 button/a 上的点击不触发）；叠层卡不响应点击 */
    onCardClick?: (id: string) => void;
}
export declare function NotificationHost({ placement, autoDismiss, className, onItemsChange, onCardClick, }: NotificationHostProps): import("react/jsx-runtime").JSX.Element | null;
