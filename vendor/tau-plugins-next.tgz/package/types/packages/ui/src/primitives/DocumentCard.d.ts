import type { ReactNode } from "react";
export declare function DocumentCardGrid({ children }: {
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
/** 尺寸使用 em，让编辑器与发布站点的卡片随正文字号一起缩放。 */
export declare function DocumentCard({ title, description, href, onClick, }: {
    title: string;
    description: string;
    href?: string;
    onClick?: () => void;
}): import("react/jsx-runtime").JSX.Element;
