/**
 * Toast 基础件 —— 轻量内联胶囊。
 *
 * 单行胶囊：类型语义色只落图标（ok/danger/warn/info，深浅主题同构），一句话 +
 * 可选动作；无关闭钮——整条点击关闭（Sonner 惯例），悬停冻结自动关闭，
 * 同一位置上限 4 条（挤掉最老）。
 * 位置四选一：top-center（默认）/ top-right / bottom-right / bottom-center，
 * 全局默认可经 toast.config 调整、单条可覆写；层级 z-[360]，高于命令面板
 * （z-[101]）与 Dialog / Drawer（z-[340]），面板或弹窗打开时操作反馈仍可见。不接 Esc（浮层退场注册表
 * 只登记阻断后退的浮层，见 D-003）。
 *
 * 用法：app 壳层挂载 <ToastHost /> 一次；任意处调用 toast.success("已保存")、
 * toast.error("失败")、toast.loading → toast.resolve(id) 或 toast.promise(p, {...})。
 */
export type ToastType = "success" | "error" | "warning" | "info" | "loading";
export type ToastPosition = "top-center" | "top-right" | "bottom-right" | "bottom-center";
export interface ToastOptions {
    /** 内联动作（如「撤销」），点击后 toast 关闭 */
    action?: {
        label: string;
        onClick: () => void;
    };
    position?: ToastPosition;
    /** 落定后的停留毫秒数；0 = 落定后也常驻（只靠点击关闭）。载入中恒常驻，与本值无关 */
    duration?: number;
    /** 关闭时回调（自动到时 / 点击整条 / 动作点击 / 同位置超限被挤出 / Host 卸载）；动作 onClick 先于它触发 */
    onClose?: () => void;
}
/**
 * 单条胶囊（受 item 驱动的纯展示件）。导出供样板间（src/showcase）构造
 * duration=0 的常显标本——产品代码仍应只消费 toast 命令式 API 与 ToastHost。
 */
export interface ToastItem {
    id: number;
    type: ToastType;
    message: string;
    action?: ToastOptions["action"];
    position: ToastPosition;
    duration: number;
    onClose?: ToastOptions["onClose"];
}
declare const defaults: {
    position: ToastPosition;
    duration: number;
};
export declare const toast: {
    /** 调整全局默认（位置 / 时长） */
    config(patch: Partial<typeof defaults>): void;
    show(type: ToastType, message: string, opts?: ToastOptions): number;
    success(message: string, opts?: ToastOptions): number;
    error(message: string, opts?: ToastOptions): number;
    warning(message: string, opts?: ToastOptions): number;
    info(message: string, opts?: ToastOptions): number;
    /** 载入中常驻；结束后 resolve（转成功）或 reject（转失败），落定起按 duration 收尾 */
    loading(message: string, opts?: ToastOptions): number;
    resolve(id: number, message?: string): void;
    reject(id: number, message?: string): void;
    dismiss(id?: number): void;
    /** promise 形态：loading → 成功/失败（文案支持按结果取值） */
    promise<T>(promise: Promise<T>, messages: {
        loading: string;
        success?: string | ((data: T) => string);
        error?: string | ((err: unknown) => string);
    }, opts?: ToastOptions): Promise<T>;
};
export declare function ToastHost(): import("react/jsx-runtime").JSX.Element;
export declare function ToastPill({ item }: {
    item: ToastItem;
}): import("react/jsx-runtime").JSX.Element;
export {};
