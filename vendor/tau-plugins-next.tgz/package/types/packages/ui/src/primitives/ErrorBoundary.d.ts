import React from "react";
interface IErrorBoundaryProps {
    children: React.ReactNode;
    fallback?: React.ReactNode;
    onError?(error: Error): void;
    key?: React.Key;
}
interface IErrorBoundaryState {
    error: string;
}
declare class ErrorBoundary extends React.Component<IErrorBoundaryProps, IErrorBoundaryState> {
    constructor(props: IErrorBoundaryProps);
    componentDidCatch(error: Error): void;
    render(): string | number | bigint | boolean | Iterable<React.ReactNode> | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined> | import("react/jsx-runtime").JSX.Element | null;
}
export default ErrorBoundary;
