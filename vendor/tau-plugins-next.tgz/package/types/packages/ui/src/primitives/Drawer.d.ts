/**
 * Drawer 基础件 —— 右侧抽屉，两种形态共用头部 / 正文 / 开合与内容保留：
 *
 * modal（默认）：距视口四边 8px 的浮起卡 + 淡遮罩（不 blur），portal 到 body 级容器。
 *   Skill / MCP 服务器 / 站点设置等「看完即走」的详情与配置。
 *   - 开合：遮罩淡入 + 卡片自右缘滑入（280ms），退场后卸载
 *   - Tab 圈闭 · 打开记录触发元素、卸载归还焦点 · 初始焦点落 [data-autofocus]（无则卡片）
 *   - 遮罩点击关闭 · 打开锁定底层滚动 · 内部 Select / Menu 继承卡片内的局部 Portal 容器
 *
 * modal={false}：就地渲染在最近的定位祖先里（默认 absolute 距上右下 12px），无遮罩、不抢焦点、
 *   不锁滚动——「边看边改」的伴随面板（待办详情、复习参考资料、白板关联笔记）。
 *   - 开合：以右缘为原点微缩 + 淡入（240ms），外框始终在容器内，不被纸的圆角裁掉
 *   - 焦点可能在抽屉外（用户回到列表 / 画布），Esc 需调用方另接页面浮层仲裁
 *     （桌面端 useOverlayDismiss）；焦点在抽屉内时由抽屉自己消费
 *
 * 共同：
 *  - 结构：头部（前导图标 · 标题 / 副标题 / 元信息三行 · 右侧操作区 + ×）→ 可选 toolbar →
 *    正文滚动区（FADE_SCROLL_CLASS + edge fade）→ 可选 footer。不传 title 即无头部，× 浮在
 *    右上角；fill 让正文不滚动、无内边距，内容自管布局（自带头部与滚动的复杂面板）
 *  - Esc 在抽屉 DOM 消费（stopPropagation）；内层 Select / Menu 先消费自己的 Esc
 *    （defaultPrevented 让位）；visible 渲染期派生，Activity 保活停驻时必然退到不可见不可点
 *  - isolateKeyboard：键盘事件在抽屉边界停止冒泡（冒泡阶段，内层编辑器照常收到），
 *    宿主在 document 上监听快捷键时（白板）用它防串键
 *  - onWidthChange：左缘出现拖拽调宽手柄，宽度受控、夹在 minWidth / maxWidth 之间
 *
 * 退场期间内容保留：抽屉多由「选中项 | null」驱动，关闭即 null 会让内容在滑出途中消失。
 * 调用方用 useRetainedValue(item) 拿到「最后一次非空值」渲染即可。
 *
 * 尺寸档：sm 440 / md 560（默认）/ lg 720，width 任意值覆盖；不超出视口（modal）/ 容器（非模态）。
 * 层级：modal z-[340]，与 Dialog 同层——后打开者在上；非模态 z-10，className 可覆盖。
 */
import { type ReactNode, type Ref } from "react";
declare const SIZE_WIDTH: {
    readonly sm: 440;
    readonly md: 560;
    readonly lg: 720;
};
export interface DrawerProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    /** 退场完成且内容卸载后调用 */
    onAfterClose?: () => void;
    /** false = 非模态伴随面板（见文件头） */
    modal?: boolean;
    /** 标题：字符串或自定义节点（如标题 + 来源标签、可编辑标题）；不传则无头部，× 浮在右上角 */
    title?: ReactNode;
    /** 无障碍名；title 不是纯字符串（或没有 title）时必填 */
    label?: string;
    /** 前导视觉（图标 / 头像 / 勾选框），尺寸由调用方决定，与标题首行顶对齐 */
    icon?: ReactNode;
    /** 标题下第二行（meta 字号 ink-3）：字符串单行截断；节点由调用方决定截断 / 折行 */
    subtitle?: ReactNode;
    /** 第三行元信息（徽标 + 计数等，sm 字号横排） */
    meta?: ReactNode;
    /** 头部右侧操作区（× 之前）：主操作按钮、更多菜单、开关等 */
    actions?: ReactNode;
    /** 头部下方、正文之上的钉住条（分区 Segmented、筛选等），不随正文滚动 */
    toolbar?: ReactNode;
    /** 底部钉住区（hairline 分隔）：保存提示、应答按钮等 */
    footer?: ReactNode;
    /** 正文不滚动、无内边距，flex 列由内容自管（自带头部与滚动的复杂面板） */
    fill?: boolean;
    /** 键盘事件不冒泡出抽屉（宿主在 document 上监听快捷键时防串键） */
    isolateKeyboard?: boolean;
    size?: keyof typeof SIZE_WIDTH;
    /** 任意宽度（px）覆盖 size；配合 onWidthChange 即受控宽度 */
    width?: number;
    /** 传入即开启左缘拖拽调宽 */
    onWidthChange?: (width: number) => void;
    minWidth?: number;
    maxWidth?: number;
    /** × 的无障碍名（默认「关闭」） */
    closeLabel?: string;
    /** 正文滚动区附加类（改内边距、字号等） */
    bodyClassName?: string;
    /** 抽屉卡片附加类（非模态常用来改定位：top-0、z-50 等） */
    className?: string;
    children?: ReactNode;
    ref?: Ref<HTMLElement>;
}
export declare function Drawer({ open, onOpenChange, onAfterClose, modal, title, label, icon, subtitle, meta, actions, toolbar, footer, fill, isolateKeyboard, size, width, onWidthChange, minWidth, maxWidth, closeLabel, bodyClassName, className, children, ref, }: DrawerProps): import("react/jsx-runtime").JSX.Element | null;
/**
 * 退场期间保留内容：返回 value；value 为空时返回最后一次非空值。
 * 抽屉由「选中项 | null」驱动时，用它渲染内容，关闭滑出途中不会变空白。
 */
export declare function useRetainedValue<T>(value: T | null | undefined): T | null;
export {};
