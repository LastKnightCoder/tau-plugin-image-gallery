/**
 * 图标按钮 —— 30px 方形无底幽灵按钮，hover 淡墨（A2 反馈语言）。
 * 尺寸/位置微调用 className 覆盖（如侧栏头 27px）。
 */
import type { ComponentProps } from "react";
export declare function IconButton({ className, type, ...props }: ComponentProps<"button">): import("react/jsx-runtime").JSX.Element;
