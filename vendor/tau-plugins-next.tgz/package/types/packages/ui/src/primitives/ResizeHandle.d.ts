/**
 * 侧栏拖宽热区：透明 8px 竖条，hover / 拖动时中部显出 2px accent 短线（不画分隔线）。
 * 栏在热区的哪一侧由 side 决定——side="left" 表示栏在热区左边（向右拖变宽），
 * "right" 表示栏在右边（向左拖变宽）。宽度夹在 [min, max]；←/→ 每次 ±16px，双击回默认宽度。
 * 定位由调用方给（className，通常 absolute 贴在栏的内缘）。pointer capture 保证拖出窗口不丢事件。
 */
export interface ResizeHandleProps {
    /** 当前宽度（受控） */
    value: number;
    min: number;
    max: number;
    onChange: (width: number) => void;
    /** 栏在热区的哪一侧 */
    side: "left" | "right";
    /** 读屏用：调整的是什么（「AI 对话栏宽度」） */
    label: string;
    /** 双击恢复的宽度；不传则双击无操作 */
    defaultValue?: number;
    /** 拖动开始 / 结束（调用方可在拖动期间关掉宽度过渡，免得跟手滞后） */
    onActiveChange?: (active: boolean) => void;
    className?: string;
}
export declare function ResizeHandle({ value, min, max, onChange, side, label, defaultValue, onActiveChange, className, }: ResizeHandleProps): import("react/jsx-runtime").JSX.Element;
