/**
 * ValueDisplay —— 值展示件（占位迁移合集）：ColorSwatch / ProgressBar / Rating。
 * Tag 已按设计稿定稿拆出 primitives/Tag.tsx（2026-09-19）；本文件剩余三件
 * 仍是未经设计稿评审的占位实现（ValueDisplay 族逐件定稿时迁出），勿在
 * 此基础上加能力。
 */
import { type TagColor } from "./Tag";
export declare function ColorSwatch({ value, onChange, disabled, }: {
    value: TagColor;
    onChange: (value: TagColor) => void;
    disabled?: boolean;
}): import("react/jsx-runtime").JSX.Element;
export declare function ProgressBar({ value, max, label, }: {
    value: number;
    max?: number;
    label: string;
}): import("react/jsx-runtime").JSX.Element;
export declare function Rating({ value, onValueChange, max, step, readOnly, label, }: {
    value: number | null;
    onValueChange?: (value: number | null) => void;
    max?: number;
    step?: 0.5 | 1;
    readOnly?: boolean;
    label?: string;
}): import("react/jsx-runtime").JSX.Element;
