/**
 * Segmented —— 分段单选器（Input 家族「连体描边」语言，mockups/segmented/，2026-09-23 定稿）。
 *
 * 02 规范 §5.2 裁决的 Tabs 官定替代：内容形态切换（字段不同构）用分段，值切换
 * （字段同构）用 Select。容器是一枚 hairline 控件（surface + line-1，与 Input /
 * Select 触发器同皮），段间 hairline 分割；激活段 accent-soft 轻染 + accent-text
 * ——零轨道、零滑块、零投影（凹槽深底形态已否决，见 mockups/segmented/ 头注）。
 *
 * 原生 input[type=radio] 承载语义（隐藏自绘皮）：组内互斥、方向键移动即选择、
 * Tab 一次进组白送。状态纪律同 Input 家族：hover 淡墨只落未选段（不冲淡激活染）、
 * press 加深一档、focus-visible 才显 ring（inset 2px 不被容器圆角裁切）。
 * 段数口径 2–5，再多该用 Select；图标段与纯图标段（label 省略，aria-label 必填）
 * 均支持。复合组件 Segmented.Item 须包在 Segmented 内（经 context 取 name/受控值）。
 * 外框默认 w-fit：放进 flex-col 等拉伸容器也按内容宽排，不会出现框宽段窄的空尾。
 */
import { type ComponentProps, type ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
export interface SegmentedProps<Value extends string> {
    /** 组名（aria-label，读屏必读；不渲染可见标签——分段器的上下文由摆放位置给出） */
    label: string;
    value?: Value;
    defaultValue?: Value;
    onValueChange?: (value: Value) => void;
    size?: "sm" | "md";
    /** 组级禁用（压过单项）；单项禁用走 Item 的 disabled */
    disabled?: boolean;
    /** radio 组提交名（默认 useId 自动生成；覆盖时须全应用内唯一） */
    name?: string;
    className?: string;
    children: ReactNode;
}
export declare function SegmentedRoot<Value extends string>({ label, value: valueProp, defaultValue, onValueChange, size, disabled, name: nameProp, className, children, }: SegmentedProps<Value>): import("react/jsx-runtime").JSX.Element;
export interface SegmentedItemProps extends Omit<ComponentProps<"input">, "type" | "value" | "name" | "checked" | "defaultChecked"> {
    /** 段值（组内唯一；选中态 = Segmented.value 等于此值） */
    value: string;
    /** 段文字；省略时为纯图标段，aria-label 必填 */
    label?: ReactNode;
    icon?: LucideIcon;
    disabled?: boolean;
}
export declare function SegmentedItem({ value, label, icon: Icon, disabled, className, ...props }: SegmentedItemProps): import("react/jsx-runtime").JSX.Element;
export declare const Segmented: typeof SegmentedRoot & {
    Item: typeof SegmentedItem;
};
