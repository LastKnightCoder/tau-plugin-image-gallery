/**
 * `@tau/editor/api`：扩展作者的渲染入口；纯服务契约经 /api/services（ER-021）。
 *
 * 只放写扩展需要的东西：声明、服务、主题、少量工具。编辑器组件、kit 工厂等宿主用的留在包根入口。
 * 未标注过渡用途的导出按稳定 API 维护；过渡导出只供现有内部消费者迁移使用。
 */
export { EXTENSION_API_VERSION, defineExtension, defineElement, type EditorExtension, type ExtensionDefinition, type ElementSpec, type ElementFrame, type ElementEmptyContext, type ElementBehaviors, type ElementRenderProps, type ExtensionLayerProps, } from "./extension";
export type { AnyExtension } from "./legacy";
export type { CopyDecision, CopyContext, ElementCopy } from "./copy";
export type { MarkSpec, MarkRenderProps, DecorationSpec } from "./marks";
export { useToolbarState } from "./toolbar";
export { default as ToolbarSubmenu } from "../components/HoveringToolbar/FloatingSubmenu";
export { Tooltip as EditorTooltip } from "../ui/Tooltip";
export { CaretRight as EditorCaretRight } from "../ui/CaretRight";
export { getParagraphShortcutEntry } from "../utils/paragraphShortcut";
export type { IngestContext, ElementIngestSpec } from "./ingest";
export { getElementResources } from "./resources";
export { ELEMENT_SELECTED_OUTLINE_CLASS, useElementFrame, type ElementFrameState, } from "../components/ElementFrame/index";
export { isOverlayTarget, isTextTarget, shouldIgnoreBlockKey } from "../utils/blockKeyTarget";
export type { ContentResourceSpec, ContentResourceKind, ContentResourceDeclarations, } from "../../../../db-schema/content-resources";
export { CommandRegistry, createCommandDispatcher, type EditorCommand, type EditorCommandContext, type EditorHotkey, type RegisteredCommand, type CommandDispatcher, type CommandGuard, } from "./command";
export { type EditorMenuEntry, type EditorMenuContext, type EditorMenuContribution, type MenuValue, } from "./menu";
export { createServiceId, IThemeService, IExtensionErrorReporter, IEditorNotifier, type ServiceIdentifier, } from "../services/tokens";
export { useService, useOptionalService, useNotifier } from "../services/hooks";
export { notifierOf } from "../services/editorNotifier";
export type { EditorNotifier, EditorFeedback, EditorLoadingHandle, EditorConfirmOptions, EditorPromptOptions, } from "../services/notifier";
export { useEditorTheme, type EditorTheme } from "../theme/context";
export type { ThemeService, EditorThemeMode } from "../theme/ThemeService";
export type { IBlockPanelListItem, IConfigItem } from "../types";
export type { CustomElement, InlineElement, BlockElement } from "../types/custom-element";
export { setOrInsertNode, canSetOrInsertNode, focusInsertedPreviewElement, } from "../utils/insertElement";
export { default as ElementMenu, type ElementMenuProps } from "../components/ElementMenu/index";
export { default as InlineChromiumBugfix } from "../components/InlineChromiumBugFix/index";
export { default as useIsLastElement } from "../hooks/useIsLastElement";
export { registerBlockNavigation, hasBlockNavigation, unregisterBlockNavigation, focusPreviousBlock, focusNextBlock, type BlockNavigationHandler, } from "../utils/blockNavigation";
export { isCollapsed, getCurrentTextNode } from "../utils/editor";
export { deleteVoidBlock } from "../utils/nodeOperations";
export { getSelectionSnapshot, isSelectionSnapshotUnchanged } from "../utils/selectionSnapshot";
export { createParagraph, isParagraphElement, type ParagraphElement } from "../model/paragraph";
export { insertParagraphAndFocus } from "../utils/editor";
export { isAtParagraphStart, isParagraphAndEmpty } from "../utils/editor";
export { isNodeEmpty } from "../kit/elementEmpty";
export { createBlockConversionMenu } from "../menu/conversion";
export { getCommandElementPath } from "../utils/commandTarget";
export { captureEditorSubmission, captureElementSubmission, captureInsertionSubmission, type Submission, type SubmissionOutcome, type SubmissionDiscardReason, } from "./submission";
export { default as AddParagraph, type AddParagraphRef } from "../components/AddParagraph/index";
export { IOverlayBackDismiss, type OverlayBackDismissProps, type OverlayBackDismissAdapter, } from "../services/overlayBackDismiss";
export { default as OverlayBackDismiss } from "../components/OverlayBackDismiss/index";
export { getElementParent, getClosestCurrentElement } from "../utils/editor";
export { getParentNodeByNode, getPreviousSiblingNode } from "../utils/element";
export { getPrevPath } from "../utils/path";
export { hitEmptyOrInlineChild, exitContainerOnEmptyParagraph } from "../utils/container";
export { replaceNode } from "../utils/editor";
export { findPathSafely } from "../utils/path";
export type { Plugin } from "../utils/plugin";
export { BLOCK_DRAG_GROUP, DragHandle, type DragHandleProps } from "../components/BlockDrag/index";
export { panAroundAnchor, pointFromCenter, type Point as ZoomPanPoint } from "../utils/zoomPan";
export { FloatingToolbar, ToolbarDivider, ToolbarIconButton } from "../components/FloatingToolbar/index";
