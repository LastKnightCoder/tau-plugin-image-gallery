declare const InlineChromiumBugfix: import("react").MemoExoticComponent<() => import("react/jsx-runtime").JSX.Element>;
export default InlineChromiumBugfix;
