import { Editor, Path } from "slate";
import { BlockElement } from "../types";
interface InsertElementOptions {
    select?: boolean;
    reverse?: boolean;
}
export declare const focusInsertedPreviewElement: (editor: Editor, path?: Path, retry?: number) => void;
/** 当前选区能否 setOrInsertNode：需折叠且落在段落内（先问再弹输入框等场景用） */
export declare const canSetOrInsertNode: (editor: Editor) => boolean;
export declare const setOrInsertNode: (editor: Editor, node: BlockElement, options?: InsertElementOptions) => Path | undefined;
export {};
