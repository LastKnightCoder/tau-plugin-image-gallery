/** 按键目标是文本输入（input / textarea / 可编辑区）：块级快捷键不拦截 */
export declare const isTextTarget: (target: EventTarget | null) => boolean;
/** 按键目标在浮层里（灯箱、裁剪编辑器、对话框）：交给浮层自己处理 */
export declare const isOverlayTarget: (target: EventTarget | null) => boolean;
/**
 * 选中媒体块时的块级快捷键是否应忽略这次按键：输入法组合、浮层内、文本输入（如说明框）都不处理。
 * 点选块后焦点通常留在外层编辑器根上——它包含这个块，不算文本输入，快捷键照常生效。
 */
export declare function shouldIgnoreBlockKey(event: KeyboardEvent, block: HTMLElement | null): boolean;
