import { type IHoveringBarContext } from "../components/HoveringToolbar/context";
/** 工具条贡献读取当前展示状态，不取得 Provider 或内部可写状态。 */
export declare function useToolbarState(): Readonly<IHoveringBarContext>;
