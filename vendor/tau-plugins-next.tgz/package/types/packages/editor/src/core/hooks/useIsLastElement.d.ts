import { Element } from "slate";
declare const useIsLastElement: (element: Element) => boolean;
export default useIsLastElement;
