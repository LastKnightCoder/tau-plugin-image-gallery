import { Element, type Descendant, type Editor } from "slate";
import type { ElementSpec } from "../api/extension";
export declare const registerElementEmpty: (editor: Editor, elements: readonly ElementSpec[]) => void;
export declare const isNodeEmpty: (node: Descendant, editor?: Editor) => boolean;
export declare const isDeclaredElementEmpty: (editor: Editor | undefined, element: Element) => boolean;
