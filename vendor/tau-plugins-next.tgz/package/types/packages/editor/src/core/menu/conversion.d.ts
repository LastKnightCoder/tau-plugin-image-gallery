import type { EditorMenuContribution, EditorMenuEntry } from "../api/menu";
/** 只组合转换菜单的展示结构，源类型与具体转换由领域提供。 */
export declare function createBlockConversionMenu(sourceTypes: readonly string[], entries: readonly EditorMenuEntry[]): Readonly<Record<string, EditorMenuContribution>>;
