import type { Editor } from "slate";
import type { ContentResourceDeclarations } from "../../../../db-schema/content-resources";
/** 内核在创建编辑器时绑定当前装配的资源声明 */
export declare function bindElementResources(editor: Editor, resources: ContentResourceDeclarations): void;
/** 当前编辑器已安装的节点资源声明（节点类型 → 资源字段） */
export declare function getElementResources(editor: Editor): ContentResourceDeclarations;
