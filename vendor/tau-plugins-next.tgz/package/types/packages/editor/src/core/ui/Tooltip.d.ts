import { type TooltipProps } from "../../../../ui/src/index";
/**
 * 编辑器内的提示：外观同 @tau/ui，层级抬到悬浮工具条（z 9999）与编辑器浮层（~10100）之上，
 * 否则工具条按钮的提示会被工具条自身盖住。
 */
export declare function Tooltip({ className, ...props }: TooltipProps): import("react/jsx-runtime").JSX.Element;
export type { TooltipProps };
