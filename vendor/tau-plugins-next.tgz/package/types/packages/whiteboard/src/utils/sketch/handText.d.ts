import type { ResolvedSketch } from "../../types/sketch";
/** 手绘文字容器的类名（D-107）；未启用手绘时为空串 */
export declare const handTextClass: (sketch: ResolvedSketch) => string;
