/** 可复现的伪随机数（mulberry32）：同一 seed 永远得到同一序列 */
export declare function createRandom(seed: number): () => number;
/** 字符串 → 32 位种子（FNV-1a），用于由元素 id 派生默认笔迹 */
export declare function hashSeed(text: string): number;
