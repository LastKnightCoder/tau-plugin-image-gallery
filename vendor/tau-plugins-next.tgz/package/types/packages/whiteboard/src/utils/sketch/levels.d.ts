import type { SketchLevel } from "../../types/sketch";
/** 各档位沿法线摆动的幅度（px） */
export declare const WOBBLE_AMPLITUDE: Record<SketchLevel, number>;
/** 墨迹宽度：比描边线宽略粗，补偿两端渐细后的视觉重量 */
export declare const inkSize: (strokeWidth: number) => number;
