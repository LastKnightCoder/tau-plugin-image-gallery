import { Selection } from "./selection";
import type { BoardElement } from "./element";
import { ViewPort } from "./viewport";
import { Path } from "./path";
import { PageSketch } from "./sketch";
export type SetNodePatch = Partial<Omit<BoardElement, "children">> & {
    children?: never;
};
export type InsertNodeOperation = {
    type: "insert_node";
    path: Path;
    node: BoardElement;
};
export type RemoveNodeOperation = {
    type: "remove_node";
    path: Path;
    node: BoardElement;
};
export type MoveNodeOperation = {
    type: "move_node";
    path: Path;
    newPath: Path;
};
export type SetNodeOperation = {
    type: "set_node";
    path: Path;
    properties: SetNodePatch;
    newProperties: SetNodePatch;
};
export type SetSelectionOperation = {
    type: "set_selection";
    properties: Partial<Selection>;
    newProperties: Partial<Selection>;
};
export type SetViewportOperation = {
    type: "set_viewport";
    properties: Partial<ViewPort>;
    newProperties: Partial<ViewPort>;
};
/** 页级画风（D-107），进撤销历史 */
export type SetSketchOperation = {
    type: "set_sketch";
    properties: Partial<PageSketch>;
    newProperties: Partial<PageSketch>;
};
export type SetMovingOperation = {
    type: "set_moving";
    properties: BoardElement[];
    newProperties: BoardElement[];
};
export type Operation = InsertNodeOperation | RemoveNodeOperation | MoveNodeOperation | SetNodeOperation | SetViewportOperation | SetSelectionOperation | SetMovingOperation | SetSketchOperation;
