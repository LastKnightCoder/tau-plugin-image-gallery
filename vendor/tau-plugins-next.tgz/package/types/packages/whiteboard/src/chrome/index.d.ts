/**
 * 画布 chrome 公共件（D-049）：
 * 工具条 / 属性浮动条 / 状态栏 / 元素树等浮动件共用一套主题语言——
 * 实底 surface + shadow-lift + 1px 细描边，不用毛玻璃与蓝调；激活 = accent-soft，悬停 = bg-hover；
 * 组内分隔靠留白（ChromeGap），不画竖线。
 *
 * 属性控件（色板 / 滑杆 / 图示选项 / 分区头）是 setter 弹层的内容：色板与派生描边承载用户数据色
 * （完整保留），外壳装饰阴影用黑色 alpha——二者不另设 token，其余一律走主题变量。
 */
import { type ComponentProps, type ReactNode, type SyntheticEvent } from "react";
import { type TooltipPlacement } from "../../../ui/src/index";
/**
 * 浮动件内的指针 / 右键 / 按键不落到画布（画布容器在祖先上监听这些事件）。
 * wheel 必须走捕获：画布的滚轮缩放/平移挂在容器上的原生 addEventListener，
 * 先于 React root 的冒泡委托触发，冒泡期的合成事件 stopPropagation 到不了它前面；
 * 捕获阶段（React root）stopPropagation 会截断整条剩余传播路径，原生监听才收不到。
 */
export declare const stopCanvasEvents: {
    onPointerDown: (e: SyntheticEvent) => void;
    onPointerUp: (e: SyntheticEvent) => void;
    onMouseDown: (e: SyntheticEvent) => void;
    onMouseUp: (e: SyntheticEvent) => void;
    onClick: (e: SyntheticEvent) => void;
    onDoubleClick: (e: SyntheticEvent) => void;
    onWheelCapture: (e: SyntheticEvent) => void;
    onKeyDown: (e: SyntheticEvent) => void;
    onContextMenu: (e: SyntheticEvent) => void;
};
export declare function ChromeBar({ className, children, ...rest }: ComponentProps<"div">): import("react/jsx-runtime").JSX.Element;
/** 组间留白（替代竖分隔线） */
export declare function ChromeGap({ className }: {
    className?: string;
}): import("react/jsx-runtime").JSX.Element;
/**
 * 工具栏语境：激活态由滑动指示块承载底色，按钮只改文字色（悬停不加背景）；
 * 工具栏以外的 ChromeButton（属性条 / 状态栏）保持 accent-soft 底色的原激活态。
 */
export declare const ToolbarContext: import("react").Context<boolean>;
export interface ChromeButtonProps extends ComponentProps<"button"> {
    /** 提示与无障碍名 */
    label: string;
    /** 激活态（当前工具 / 开关已开） */
    active?: boolean;
    /** 带子菜单：右下角固定小三角（占位固定，悬停不改尺寸） */
    sub?: boolean;
    kbd?: string;
    tooltipPlacement?: TooltipPlacement;
}
/**
 * 浮动件图标按钮：30px，Tooltip 包在 button 外、ref 与注入的 props 透传到 button——
 * 所以可以直接作为 Menu / Popover 的 trigger。展开时（aria-expanded）按下态、并暂停提示。
 */
export declare function ChromeButton({ label, active, sub, kbd, tooltipPlacement, className, children, ref, ...rest }: ChromeButtonProps): import("react/jsx-runtime").JSX.Element;
/** 属性条的弹层方向：条在元素上方 → 向上展开；翻到元素下方 → 向下展开 */
export declare const AttrBarContext: import("react").Context<{
    side: "top" | "bottom";
}>;
export interface AttrPopoverProps {
    label: string;
    /** 条目图标；与 swatch 二选一 */
    icon?: ReactNode;
    /** 颜色条目用当前色的小圆点代替通用图标（数据色） */
    swatch?: SwatchLook;
    /** 分区头右侧的开关（开关型属性：开关放标题右侧，下面不再写同名开关） */
    toggle?: {
        checked: boolean;
        onChange: (v: boolean) => void;
    };
    children?: ReactNode;
    /** 弹层宽度，默认 280 */
    width?: number;
}
export declare function AttrPopover({ label, icon, swatch, toggle, children, width, }: AttrPopoverProps): import("react/jsx-runtime").JSX.Element;
/** 纯开关项：点一下直接切换，按钮本身显示开 / 关 */
export declare function AttrToggle({ label, icon, checked, onChange, }: {
    label: string;
    icon: ReactNode;
    checked: boolean;
    onChange: (v: boolean) => void;
}): import("react/jsx-runtime").JSX.Element;
/** 动作项：直接执行（适应内容 / 解散 / 对齐…） */
export declare function AttrAction({ label, icon, onClick, disabled, }: {
    label: string;
    icon: ReactNode;
    onClick: () => void;
    disabled?: boolean;
}): import("react/jsx-runtime").JSX.Element;
/** 弹层内的子字段：小标题 + 控件（纵向从属，不做左右两列） */
export declare function Field({ label, value, children, className, }: {
    label?: ReactNode;
    value?: ReactNode;
    children: ReactNode;
    className?: string;
}): import("react/jsx-runtime").JSX.Element;
export interface SwatchLook {
    fill: string;
    stroke?: string;
    /** default = 「默认」（墨色环）；none = 无 / 透明（斜线） */
    kind?: "default" | "none";
}
export declare function SwatchDot({ look }: {
    look: SwatchLook;
}): import("react/jsx-runtime").JSX.Element;
export interface SwatchOption extends SwatchLook {
    key: string;
    label: string;
}
/** 色板：22px 圆色块，选中 = surface 间隙 + accent 外环 */
export declare function SwatchRow({ options, value, onChange, custom, }: {
    options: SwatchOption[];
    value: string | null | undefined;
    onChange: (key: string) => void;
    /** 末尾「自定义颜色」 */
    custom?: {
        value?: string;
        onChange: (hex: string) => void;
    };
}): import("react/jsx-runtime").JSX.Element;
/** 滑杆：accent 轨道 + 右侧数值 */
export declare function Slider({ value, min, max, step, unit, onChange, onCommit, format, label, }: {
    value: number;
    min: number;
    max: number;
    step?: number;
    unit?: string;
    onChange: (v: number) => void;
    /** 拖动结束（需要合并为一次历史记录的调用方用） */
    onCommit?: (v: number) => void;
    format?: (v: number) => string;
    label?: string;
}): import("react/jsx-runtime").JSX.Element;
/**
 * 步进器：− 按钮 / 数值输入 / + 按钮（档位按钮之外的精确微调）。
 * 单位后缀走 unit 文字：NumberInput 事前拦截只放行数字，后缀进输入框会被剥掉。
 */
export declare function Stepper({ value, min, max, step, onChange, label, unit, }: {
    value: number;
    min: number;
    max: number;
    step?: number;
    onChange: (v: number) => void;
    label: string;
    /** 输入框右侧紧贴的单位字（如 "%"） */
    unit?: string;
}): import("react/jsx-runtime").JSX.Element;
export interface OptionItem<V extends string> {
    value: V;
    label: string;
    /** 图示（线型 / 箭头端点 / 画框样式…）；不给则显示 label */
    glyph?: ReactNode;
    /** 图示 + 文字同时显示 */
    showLabel?: boolean;
}
/** 图示选项块：等宽网格，选中 = accent-soft + accent 描边 */
export declare function OptionGrid<V extends string>({ options, value, onChange, cols, tall, }: {
    options: OptionItem<V>[];
    value: V | null | undefined;
    onChange: (v: V) => void;
    cols?: number;
    /** 图块（上图下字，54px 高） */
    tall?: boolean;
}): import("react/jsx-runtime").JSX.Element;
/** 文字分段（连体描边 Segmented，满宽） */
export declare function Seg<V extends string>({ label, options, value, onChange, }: {
    label: string;
    options: {
        value: V;
        label?: string;
        icon?: import("lucide-react").LucideIcon;
    }[];
    value: V;
    onChange: (v: V) => void;
}): import("react/jsx-runtime").JSX.Element;
/** 小图示 svg（28×14 画布，stroke = currentColor） */
export declare function Glyph({ children }: {
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
/** 线宽档位：横条高度 = 线宽（封顶 8px） */
export declare function LineWeightGlyph({ width }: {
    width: number;
}): import("react/jsx-runtime").JSX.Element;
/** 圆角档位：左上折角的圆角 = radius / 2（封顶 10px）；0 即直角 */
export declare function CornerGlyph({ radius }: {
    radius: number;
}): import("react/jsx-runtime").JSX.Element;
/** 不透明度档位：色块浓度 = currentColor 与透明的混合 + 内嵌细描边 */
export declare function OpacityGlyph({ opacity }: {
    opacity: number;
}): import("react/jsx-runtime").JSX.Element;
