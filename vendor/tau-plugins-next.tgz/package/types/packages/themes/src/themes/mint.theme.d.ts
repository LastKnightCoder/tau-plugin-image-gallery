/**
 * 主题「薄荷」—— 取自移动端薄荷 Mint（浅色·清新）：灰绿纸底 + 松墨 + 翠绿 accent。
 *
 * 浅色（晴）：底色 / 墨色 / 状态色沿用移动端；ink-2 与 accent 按桌面 AA 门禁压深。
 * 深色（夜林）：移动端无深色版，按同色相推演——墨绿夜底 + 淡薄荷白墨 + 中饱和翠绿 accent；
 * 绿调强度介于「整页泛绿」与「近中性（与水墨 · 松烟难分）」之间。
 *
 * 对比度按 02 规范 §2.5，深浅两套均由 theme-parity.test.ts 校验。
 */
declare const _default: import("../defineTheme").ThemeDefinition;
export default _default;
