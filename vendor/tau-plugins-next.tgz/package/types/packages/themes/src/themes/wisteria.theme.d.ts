/**
 * 主题「紫藤」—— 淡紫灰纸底 + 暮紫墨 + 紫藤色 accent，柔和文艺。
 *
 * 浅色（晴）：纸底带一丝紫调，墨色取暮紫而非纯黑，accent 为中明度紫藤色。
 * 深色（夜紫）：深紫夜底 + 藤白墨 + 紫藤提亮；层级口径同暖纸 · 夜。
 *
 * 对比度按 02 规范 §2.5，深浅两套均由 theme-parity.test.ts 校验。
 */
declare const _default: import("../defineTheme").ThemeDefinition;
export default _default;
