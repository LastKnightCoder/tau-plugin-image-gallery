/**
 * 主题「暖纸」—— 首个主题族，一张暖纸的晨与夜。
 *
 * 浅色（晨）：取值来自样板间 direction-a-soft.html 的实测调优结果；奶油纸底 + 可可墨 +
 * 陶土橙 accent（与移动端「杏子 Bento」同基因）。融合骨架要求：不提供侧栏专用底色，
 * 侧栏透明融于 bg-page（见 03 指南 · 壳层铁律）。
 *
 * 深色（夜）：同一张暖纸在烛光下——深可可纸底 + 奶油墨 + 陶土橙提亮。层级与浅色对称翻转：
 * surface 最亮（卡片浮起）、sunken 最暗（凹陷）；交互态改奶油墨低透明叠层（对应浅色的
 * 可可墨叠层）；阴影加深至黑系。
 *
 * 对比度按 02 规范 §2.5：ink-1 对 page/surface ≥ 7:1、ink-2 与 accent 文字 ≥ 4.5:1
 * （由 theme-parity.test.ts 的对比度断言守护，深浅两套都校验）。
 */
declare const _default: import("../defineTheme").ThemeDefinition;
export default _default;
