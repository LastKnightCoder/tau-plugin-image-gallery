import type { ServiceIdentifier } from "./service-contract";
/**
 * 服务注册表：宿主平台能力的统一容器。
 * 注册与消费均以 ServiceIdentifier 匹配；可由编辑器、白板等宿主共享使用。
 */
export interface ServiceRegistry {
    /** 获取必选服务，未注册时抛出包含服务 id 的错误 */
    get<T>(id: ServiceIdentifier<T>): T;
    /** 获取可选服务，未注册时返回 undefined；用于消费侧显式降级 */
    tryGet<T>(id: ServiceIdentifier<T>): T | undefined;
    has<T>(id: ServiceIdentifier<T>): boolean;
}
/**
 * 注册单个服务。实现值既可以是实例，也可以是 `(registry) => impl` 工厂：
 * 工厂在首次 get 时才求值，因此注册顺序无关，且可在工厂内依赖其他服务。
 * 注意：注册的值如果本身是函数，会被视为工厂。
 */
export type ServiceRegister = <T>(id: ServiceIdentifier<T>, impl: T | ((registry: ServiceRegistry) => T)) => void;
export type ServiceRegistration = (register: ServiceRegister) => void;
export declare function createServiceRegistry(...registrations: ServiceRegistration[]): ServiceRegistry;
/**
 * 基于父注册表派生子注册表：get 时优先命中子级覆盖项，未命中则委托父级。
 * 用于协同编辑等需要按上下文覆盖个别服务的场景，覆盖粒度可到单个服务。
 */
export declare function createChildRegistry(parent: ServiceRegistry, ...overrides: ServiceRegistration[]): ServiceRegistry;
