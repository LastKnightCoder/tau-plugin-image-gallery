import type { ComponentType } from "react";
import type { Disposable, PluginContext } from "./index";
import type { JsonValue } from "./json";
export type PluginPageParams = Record<string, string | number | boolean>;
export interface PluginPageContext {
    /** 在组件 effect 中登记当前状态提供器；返回值的形状由插件决定。 */
    register(provider: () => JsonValue): Disposable;
}
export interface PluginPageProps {
    readonly context: PluginContext;
    readonly params: Readonly<PluginPageParams>;
    readonly pageContext: PluginPageContext;
}
export interface PluginPageDefinition {
    id: string;
    title: string;
    component: ComponentType<PluginPageProps>;
    match?: "single" | "params";
    /** params 页缺省按完整参数区分实例；提供时只按该身份去重。 */
    getId?(params: Readonly<PluginPageParams>): string;
}
export interface PluginPageHandle extends Disposable {
    readonly id: string;
    open(params?: PluginPageParams): Promise<void>;
}
export interface PluginPages {
    register(definition: PluginPageDefinition): PluginPageHandle;
}
export declare function normalizePageParams(value: unknown): PluginPageParams;
