export declare function assertLocalId(value: string): void;
