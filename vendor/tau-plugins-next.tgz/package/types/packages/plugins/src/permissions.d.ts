export declare const PLUGIN_PERMISSIONS: readonly ["cards:read", "cards:write", "cards:delete", "articles:read", "articles:write", "articles:delete", "documents:read", "documents:write", "todos:read", "todos:write", "todos:delete", "calendar:read", "calendar:write", "calendar:delete", "flashcards:read", "flashcards:write", ...("ai:chat" | "ai:titleSummary" | "ai:webClip" | "ai:podcastGeneration" | "ai:flashcardGeneration" | "ai:aiJudgement" | "ai:transcriptionOptimization" | "ai:videoSummary" | "ai:videoEbookRewrite" | "ai:vibeLearningImageDescription" | "ai:contentMetadata" | "ai:contentInsights")[]];
export type PluginPermission = (typeof PLUGIN_PERMISSIONS)[number];
export declare const isPluginPermission: (value: unknown) => value is PluginPermission;
/** granted：可直接调用；prompt：调用时会询问用户；denied：本次运行已拒绝或已被阻止 */
export type PluginPermissionState = "granted" | "prompt" | "denied";
/**
 * undeclared：manifest 未声明；denied：用户拒绝；blocked：用户已阻止，需到插件详情页解除；
 * unavailable：应用不在前台无法询问，请求已记入插件详情页等待用户处理。
 */
export type PluginPermissionDenial = "undeclared" | "denied" | "blocked" | "unavailable";
export declare class PluginPermissionError extends Error {
    readonly name = "PluginPermissionError";
    readonly permission: PluginPermission;
    readonly reason: PluginPermissionDenial;
    constructor(permission: PluginPermission, reason: PluginPermissionDenial);
}
export interface PluginPermissions {
    query(permission: PluginPermission): Promise<PluginPermissionState>;
    /** 一次询问多项；全部获准时返回 true。已获准的不再询问。 */
    request(permissions: readonly PluginPermission[]): Promise<boolean>;
}
/** 读取 manifest.permissions；strict 用于门户上传，客户端静默丢弃未知权限。 */
export declare function readPermissionsField(item: Record<string, unknown>, strict: boolean): {
    permissions?: readonly PluginPermission[];
};
