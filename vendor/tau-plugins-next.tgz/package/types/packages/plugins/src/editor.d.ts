import type { EditorExtension as InternalExtension } from "../../editor/contracts";
import type { MarkdownCodec } from "../../markdown/src/index";
import type { Disposable } from "./index";
export { defineElement as defineEditorElement } from "../../editor/contracts";
export type { ElementRenderProps as EditorElementRenderProps } from "../../editor/contracts";
export type { MarkdownCodec as EditorMarkdownCodec } from "../../markdown/src/index";
export type { ContentResourceSpec as EditorResourceSpec, ContentResourceKind as EditorResourceKind, } from "../../db-schema/content-resources";
/** 作者通过模块增强登记自定义节点，无需引用编辑器内部包。 */
declare const elementMapBrand: unique symbol;
declare const inlineMapBrand: unique symbol;
export interface EditorElementMap {
    [elementMapBrand]: never;
}
export interface EditorInlineElementMap {
    [inlineMapBrand]: never;
}
declare module "../../editor/api" {
    interface ExtensionElementMap extends EditorElementMap {
        [elementMapBrand]: never;
    }
    interface ExtensionInlineElementMap extends EditorInlineElementMap {
        [inlineMapBrand]: never;
    }
}
export type PluginEditorExtension = Pick<InternalExtension, "id" | "apiVersion" | "elements" | "commands" | "hotkeys" | "menu" | "blockPanel" | "behaviorsFor"> & {
    plugins?: never;
    /** 发布时从节点字段收集 Tailwind 源码，复用宿主编译器。 */
    styleSources?: readonly {
        type: string;
        field: string;
        language: "html" | "tsx";
    }[];
    /** 静态 HTML/EPUB 导出；博客始终使用 elements.render，不经过这里。 */
    htmlSerializers?: readonly {
        type: string;
        toHtml(element: Record<string, unknown>): string;
    }[];
};
export declare function defineEditorExtension(definition: Omit<PluginEditorExtension, "apiVersion">): PluginEditorExtension;
export interface PluginEditorContribution {
    /** 目前只有开发台场景；其他场景需宿主明确接入后开放。 */
    scene: "workbench";
    extension: PluginEditorExtension;
    /** 纯函数定义可由主进程独立导入，本次只在开发台装配。 */
    codecs?: readonly MarkdownCodec[];
}
export interface PluginEditor {
    register(contribution: PluginEditorContribution): Disposable;
}
