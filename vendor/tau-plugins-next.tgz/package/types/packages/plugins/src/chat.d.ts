import type { ComponentType, ReactNode } from "react";
import type { ToolCallExecutionState } from "../../shared/src/chat-core/index";
import type { Disposable } from "./contract";
import type { JsonValue } from "./json";
export type { ToolCallExecutionState } from "../../shared/src/chat-core/index";
export interface PluginToolRendererProps {
    execution: Readonly<ToolCallExecutionState>;
    isDark: boolean;
    parsedInput: unknown | null;
    inputParseError?: string;
    data: JsonValue | null;
    dataVersion: number | null;
    renderDefault(): ReactNode;
}
export interface PluginToolRendererDefinition {
    mcpId: string;
    toolName: string;
    component: ComponentType<PluginToolRendererProps>;
}
export interface PluginChat {
    /** 激活成功后发布，停用时自动回收；展示不受 MCP 执行开关影响。 */
    registerToolRenderer(definition: PluginToolRendererDefinition): Promise<Disposable>;
}
export declare function snapshotToolRendererDefinition(definition: PluginToolRendererDefinition): PluginToolRendererDefinition;
