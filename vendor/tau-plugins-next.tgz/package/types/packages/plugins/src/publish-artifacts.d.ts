export { validatePluginManifest, PLUGIN_SHARED_MODULES } from "./package";
import type { DevelopmentPluginPackage } from "./package";
export declare const PLUGIN_RENDER_VERSION: 1;
export type { PublishedPluginRender } from "./render-artifact";
/** 协议层只检查贡献归属，具体扩展类型由模板选用的渲染器解释。 */
export interface EvaluatedPluginDefinition {
    id: string;
    name: string;
    version: string;
    apiVersion: 1;
    editorExtensions?: readonly unknown[];
}
export declare function evaluatePluginPackage(artifact: DevelopmentPluginPackage, modules: Readonly<Record<string, unknown>>): EvaluatedPluginDefinition;
export declare function assertRenderTypes(definition: EvaluatedPluginDefinition, types: string[]): void;
