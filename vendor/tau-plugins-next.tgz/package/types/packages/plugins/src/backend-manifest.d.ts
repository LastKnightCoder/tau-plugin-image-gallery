export declare const PLUGIN_SYSTEM_ACCESS: readonly ["filesystem", "network", "process"];
export type PluginSystemAccess = (typeof PLUGIN_SYSTEM_ACCESS)[number];
export interface PluginBackendManifest {
    tools?: readonly {
        id: string;
        command: string;
        args?: readonly string[];
    }[];
    entry: string;
    runtime: "node";
    apiVersion: 1;
    scope: "application" | "workspace";
    activation: "on-demand" | "app-ready" | "workspace-ready";
    lifetime: "idle" | "persistent";
    reason: string;
    /** 系统用途披露，不表示操作系统级权限限制。 */
    systemAccess: readonly PluginSystemAccess[];
}
export declare function validateBackendManifest(value: unknown): PluginBackendManifest;
