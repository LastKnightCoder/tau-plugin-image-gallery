import type { ReactElement } from "react";
import type { PluginContentRef } from "./data";
/**
 * 与卡片详情相同的正文编辑器：协作、内置与已安装的编辑器扩展、文档待办都由宿主提供。
 * 可编辑需要所属实体的写入权限，只读需要读取权限；未授权时显示「允许访问」，由用户点击后询问。
 * 只能在插件页面内使用。
 */
export interface ContentEditorProps {
    contentRef: PluginContentRef;
    /** 默认 false */
    readonly?: boolean;
    /** 正文为空时的提示文字 */
    placeholder?: string;
    /** 打开后滚动并闪烁到的位置：从 Tau 打开插件内容时页面参数 params.at 原样传入 */
    at?: string;
}
/** 正文开头几块的只读渲染，用于列表与卡面；需要所属实体的读取权限。 */
export interface ContentPreviewProps {
    contentRef: PluginContentRef;
    /** 显示的块数，默认 3 */
    maxBlocks?: number;
}
/** 宿主注入的实现；SDK 根入口只引用 React 类型，不加载 React 运行时。 */
export interface ContentComponentsRuntime {
    ContentEditor(props: ContentEditorProps): ReactElement | null;
    ContentPreview(props: ContentPreviewProps): ReactElement | null;
}
export declare function configureContentComponents(value: ContentComponentsRuntime): void;
export declare const ContentEditor: (props: ContentEditorProps) => ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | null;
export declare const ContentPreview: (props: ContentPreviewProps) => ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | null;
