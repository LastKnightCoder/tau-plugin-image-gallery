import type { Disposable } from "./contract";
export type PluginNotificationMode = "auto" | "in-app" | "system";
export interface PluginNotificationAction {
    label: string;
    primary?: boolean;
    resolvedText?: string;
    onClick(): void | Promise<void>;
}
export interface PluginNotificationOptions {
    title: string;
    body?: string;
    /** 默认 auto：插件所在窗口聚焦时应用内展示，否则进入独立通知窗口。 */
    mode?: PluginNotificationMode;
    tone?: "neutral" | "ok" | "danger";
    /** 常驻到用户处理或关闭，默认 false。 */
    sticky?: boolean;
    /** 最多两个按钮，最多一个主按钮；回调在插件所在窗口执行。 */
    actions?: readonly PluginNotificationAction[];
}
export interface PluginNotifications {
    /** 发送通知，dispose 撤销这一条；停用、激活失败或切库时自动撤销。 */
    send(options: PluginNotificationOptions): Disposable;
}
/** 只复制公开字段，避免插件对象或回调进入跨进程载荷。 */
export declare function readNotificationOptions(input: PluginNotificationOptions): PluginNotificationOptions;
