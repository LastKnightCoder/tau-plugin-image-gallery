/**
 * Markdown 位置（CodeMirror 格式）
 */
export interface MarkdownPosition {
    line: number;
    ch: number;
}
/**
 * Slate 位置
 */
export interface SlatePosition {
    path: number[];
    offset: number;
}
/**
 * 文本级别的映射条目
 * 用于普通文本节点，支持字符级精确映射
 */
export interface TextMapping {
    type: "text";
    slateTextPath: number[];
    slateOffset: number;
    slateLength: number;
    mdLine: number;
    mdCh: number;
    mdLength: number;
    prefixLength: number;
    suffixLength: number;
    sourceOffsets?: readonly number[];
    /** 手工改写的载体无法证明字符对应时，只提供首尾边界。 */
    opaque?: boolean;
    mdEnd?: MarkdownPosition;
}
/**
 * 元素级别的映射条目
 * 用于 void 元素（code-block, image 等）
 */
export interface ElementMapping {
    type: "element";
    slateElementPath: number[];
    elementType: string;
    isVoid: true;
    mdStartLine: number;
    mdStartCh: number;
    mdEndLine: number;
    mdEndCh: number;
    propertyMappings?: {
        [propName: string]: {
            mdStartLine: number;
            mdStartCh: number;
            mdEndLine: number;
            mdEndCh: number;
        };
    };
}
export type PositionMapping = TextMapping | ElementMapping;
/**
 * 位置映射器类（重新设计版本）
 *
 * 核心改进：
 * 1. 文本节点级别映射（而非元素级别）
 * 2. 支持格式标记的偏移处理
 * 3. 双向映射都基于相同的数据结构
 */
export declare class PositionMapper {
    private mappings;
    /**
     * 添加文本映射
     */
    addTextMapping(mapping: TextMapping): void;
    /**
     * 添加元素映射（void 元素）
     */
    addElementMapping(mapping: ElementMapping): void;
    /**
     * 清空映射表
     */
    clear(): void;
    /**
     * Slate 位置 → Markdown 位置
     *
     * @param pos Slate position {path: [0, 0], offset: 5}
     * @returns Markdown position {line: 2, ch: 15} 或 null
     */
    slateToMarkdown(pos: SlatePosition): MarkdownPosition | null;
    /**
     * Markdown 位置 → Slate 位置
     *
     * @param pos Markdown position {line: 2, ch: 15}
     * @returns Slate position {path: [0, 0], offset: 5} 或 null
     */
    markdownToSlate(pos: MarkdownPosition): SlatePosition | null;
    /**
     * 获取所有映射（调试用）
     */
    getMappings(): PositionMapping[];
    /**
     * 根据 Slate 元素路径查找元素映射
     */
    getElementMappingBySlatePath(path: number[]): ElementMapping | null;
    /**
     * 根据 Markdown 位置查找元素映射与属性信息
     */
    getElementPropertyByMarkdown(pos: MarkdownPosition): {
        mapping: ElementMapping;
        propertyName?: string;
        relativePos?: MarkdownPosition;
    } | null;
    /**
     * 清理无效路径的映射
     */
    pruneInvalidPaths(isValidPath: (path: number[]) => boolean): void;
    /**
     * 打印映射表（调试用）
     */
    debug(): void;
    /**
     * 调整子元素映射的位置（用于处理 childrenStart 和 perLineOffset）
     *
     * @param parentPath 父元素路径，如 [0]
     * @param childrenStart 子元素内容在父输出中的起始位置
     * @param perLineOffset 每行的额外偏移（用于 blockquote "> ", list "- " 等）
     */
    adjustChildMappings(parentPath: number[], childrenStart: {
        line: number;
        ch: number;
    }, perLineOffset?: number, baseLine?: number): void;
    /**
     * 对指定子元素索引之后的映射进行行号偏移
     */
    shiftLinesForChildren(parentPath: number[], startIndex: number, lineDelta: number): void;
    /**
     * 调整内联包装元素（如 link）的子文本映射
     */
    adjustChildMappingsForInlineWrapper(parentPath: number[], wrapperPrefixLength: number, wrapperSuffixLength: number): void;
    /**
     * 判断 childPath 是否是 parentPath 的子路径
     * 例如：[0, 1, 2] 是 [0, 1] 的子路径
     */
    private isChildPath;
    /**
     * 根据 Slate path 查找映射
     */
    private findMappingBySlate;
    /**
     * 根据 Markdown 位置查找映射（二分查找）
     */
    private findMappingByMarkdown;
    /**
     * 判断 Markdown 位置是否在元素范围内
     */
    private isWithinElementRange;
    /**
     * 判断 Markdown 位置是否在范围内（end 为排他）
     */
    private isWithinRange;
    /**
     * 判断位置是否落在区间结束边界（end inclusive，仅用于光标映射）
     */
    private isAtRangeInclusiveEnd;
}
