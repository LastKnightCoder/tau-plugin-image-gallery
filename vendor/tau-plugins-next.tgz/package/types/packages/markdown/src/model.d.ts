/** 扩展通过纯类型入口增强标记字段，框架不拥有具体格式。 */
export interface TextMarkMap {
}
export interface FormattedText extends TextMarkMap {
    type: "formatted";
    text: string;
}
