# Tau 插件开发包 @tau/plugins

开发 Tau 插件所需的类型与接口，通过 npm 别名安装为 `@tau/plugins`。根入口的实现由 Tau 在运行时提供，插件构建时需设为 external。

从模板开始开发：https://github.com/LastKnightCoder/tau-plugin-template

开发文档见 [docs/README.md](docs/README.md)。
